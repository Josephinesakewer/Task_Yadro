# DAG Service API

# Микросервис для управления направленными ациклическими графами (DAG)

## Запуск
```bash
docker-compose up --build
